#!/usr/bin/env bash

source h-manifest.conf
source /hive/miners/custom/apoolminer_hiveos_qubic_nock_mining/apoolminer_hiveos_qubic_nock_mining.conf
algo=$(grep 'META' /hive-config/wallet.conf | awk -F '=' '{print $2}' | tr -d '"' | sed -n 's/.*coin:\([^}]*\).*/\1/p' | tr '[:upper:]' '[:lower:]')
stats=""
khs=0

if [[ "$algo" == "qubic" ]]; then
    # Qubic 
    gpus_raw=$(curl -s --connect-timeout 3 --max-time 5 http://127.0.0.1:5001/gpu)

    if [[ $? -ne 0 || -z $gpus_raw ]]; then
        echo -e "${RED}Failed to get gpus info from 127.0.0.1:5001/gpu${NOCOLOR}"
    else
        data=$(echo "$gpus_raw" | jq -cr '.data')
        readarray -t temp_data < <(echo "$data" | jq -cr '.uptime, ([.gpus[].proof]|add/1000), [.gpus[].proof], [.gpus[].ctmp], [.gpus[].fan], ([.gpus[].valid]|add), ([.gpus[].inval]|add), [.gpus[].bus] ' 2>/dev/null)

        unit="it"
        uptime="${temp_data[0]/s/}"
        khs="${temp_data[1]}"
        khs=$(echo $khs | sed -E 's/^( *[0-9]+\.[0-9]([0-9]*[1-9])?)0+$/\1/')
        hs="${temp_data[2]}"
        temp="${temp_data[3]}"
        fan="${temp_data[4]}"
        accepted="${temp_data[5]}"
        rejected="${temp_data[6]}"
        bus_numbers="${temp_data[7]}"
        version="$CUSTOM_VERSION"

        stats=$(jq -nc --arg khs "$khs" \
                       --argjson hs "$hs" \
                       --arg hs_units "$unit" \
                       --argjson temp "$temp" \
                       --argjson fan "$fan" \
                       --arg accepted "$accepted" \
                       --arg rejected "$rejected" \
                       --arg uptime "$uptime" \
                       --arg ver "$version" \
                       --arg algo "$algo" \
                       --argjson bus_numbers "$bus_numbers" \
                       '{$hs, "hs_units": $hs_units, 
                         $temp, $fan, "ar": [$accepted | tonumber, $rejected | tonumber], $bus_numbers,
                         "uptime": $uptime | tonumber | floor, $ver, $algo}')

        echo "$stats"
    fi
elif [[ "$algo" == "nock" ]]; then

#!/usr/bin/env bash

# --- Standard HiveOS & Miner Config ---
. /hive-config/rig.conf
. /hive/miners/custom/apoolminer_hiveos_qubic_nock_mining/h-manifest_nock.conf

LOG_FILE="$CUSTOM_LOG_BASENAME.log"
GPU_STATS_JSON="/run/hive/gpu-stats.json"
# State file written by h-run.sh
GPU_LIST_FILE="/var/run/hive/nockminer_gpus.conf"

# Exit if log file doesn't exist
if [ ! -f "$LOG_FILE" ]; then
    echo "null"
    exit 0
fi

# --- Read Base GPU Stats for the ENTIRE rig from HiveOS ---
readarray -t gpu_stats < <(jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" 2>/dev/null)
busids=(${gpu_stats[0]})
brands=(${gpu_stats[1]})
temps=(${gpu_stats[2]})
fans=(${gpu_stats[3]})
gpu_count=${#busids[@]}

BRAND_MINER="nvidia"

# ===================================================================================
# ======================== FINAL & FOCUSED LOGIC ====================================
# ===================================================================================

# 1. Get the global HiveOS indices for all GPUs of the target brand.
#    e.g., all_nvidia_hive_indices becomes (0 1) for your rig.
all_nvidia_hive_indices=()
for (( i=0; i < gpu_count; i++ )); do
    if [[ "${brands[i]}" == "$BRAND_MINER" ]]; then
        all_nvidia_hive_indices+=($i)
    fi
done

# 2. Prepare empty arrays for the FINAL report. These will only contain
#    data for the GPUs this miner is actually using.
final_hs=()
final_bus_numbers=()
final_temp=()
final_fan=()

# 3. Read the list of ACTIVE GPUs from the file saved by h-run.sh.
if [[ -f "$GPU_LIST_FILE" ]]; then
    MINER_GPU_LIST=$(<"$GPU_LIST_FILE")
    IFS=',' read -ra active_miner_indices <<< "$MINER_GPU_LIST"

    # 4. Loop through ONLY the active GPUs to build the report.
    card_log_idx=0
    for miner_relative_idx in "${active_miner_indices[@]}"; do
        # A. Find the global HiveOS index for this active GPU.
        #    e.g., if miner_relative_idx is 0, global_hive_idx becomes 0.
        #    e.g., if miner_relative_idx is 1, global_hive_idx becomes 1.
        global_hive_idx=${all_nvidia_hive_indices[$miner_relative_idx]}

        # B. Get the hashrate from the log for this card.
        gpu_raw=$(grep -w "Card-${card_log_idx} speed:" "$LOG_FILE" | tail -n 1)
        hashrate=0
        if [[ -n "$gpu_raw" ]]; then
            hashrate_str=$(echo "$gpu_raw" | awk '{print $(NF-1)}' | sed 's/[^0-9.]//g')
            [[ -n "$hashrate_str" ]] && hashrate=$(awk "BEGIN {printf \"%.6f\", $hashrate_str/1000}")
        fi
        final_hs+=($hashrate)

        # C. Get the Bus ID, Temp, and Fan for this specific GPU.
        short_busid="${busids[$global_hive_idx]}"
        [[ "$short_busid" =~ ^([A-Fa-f0-9]+): ]] && decimal_busid=$((16#${BASH_REMATCH[1]})) || decimal_busid=0
        final_bus_numbers+=($decimal_busid)
        final_temp+=(${temps[$global_hive_idx]})
        final_fan+=(${fans[$global_hive_idx]})

        ((card_log_idx++))
    done
fi

# ===================================================================================
# ============================ NEW LOGIC ENDS HERE ==================================
# ===================================================================================

# --- Collect Other Stats & Build Final JSON ---
# The JSON is now built from our focused "final_" arrays.

# Count how many times "Heartbeat success" appears in the log
heartbeat_success_count=$(grep -c "Heartbeat success" "$LOG_FILE" 2>/dev/null)
[[ -z "$heartbeat_success_count" ]] && heartbeat_success_count=0

hash_json=$(printf '%s\n' "${final_hs[@]}" | jq -cs '.')
bus_json=$(printf '%s\n' "${final_bus_numbers[@]}" | jq -cs '.')
fan_json=$(printf '%s\n' "${final_fan[@]}" | jq -cs '.')
temp_json=$(printf '%s\n' "${final_temp[@]}" | jq -cs '.')

total_hashrate=$(awk '{s=0; for(i=1;i<=NF;i++)s+=$i; print s}' <<< "${final_hs[*]}")
khs=$total_hashrate

uptime=$(( $(date +%s) - $(stat -c %Y "$CUSTOM_CONFIG_FILENAME") ))
ver=$(grep -m1 -oE "version: *[0-9]+\.[0-9]+(\.[0-9]+)?" "$LOG_FILE" | awk '{print $2}')
[[ -z "$ver" ]] && ver="unknown"

stats=$(jq -nc \
    --argjson hs "$hash_json" \
    --arg hs_units "H/s" \
    --arg algo "nock" \
    --arg ver "$ver" \
    --argjson bus_numbers "$bus_json" \
    --argjson fan "$fan_json" \
    --argjson temp "$temp_json" \
    --arg uptime "$uptime" \
    --argjson shares_acc "$heartbeat_success_count" \
    --argjson shares_rej 0 \
    --arg khs "$khs" \
    '{hs: $hs, hs_units: $hs_units, algo: $algo, ver: $ver,
      uptime: ($uptime|tonumber), bus_numbers: $bus_numbers,
      temp: $temp, fan: $fan, khs: ($khs|tonumber),
      ar: [$shares_acc, $shares_rej]}'
)

echo "$stats"
fi

#echo $khs
#echo $stats
fi
