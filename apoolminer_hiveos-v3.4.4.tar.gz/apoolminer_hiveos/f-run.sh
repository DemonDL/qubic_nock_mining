#!/bin/bash

[ -t 1 ] && . colors
  
ACCOUNTNAME=$(grep 'CUSTOM_PASS' /hive-config/wallet.conf | sed 's/^CUSTOM_PASS="//' | sed 's/"$//')
FREQIDLE=$(echo "$ACCOUNTNAME" | awk -F '%FREQIDLE=|%FREQQUBIC' '{print $2}' | sed 's/ *$//')
FREQQUBIC=$(echo "$ACCOUNTNAME" | awk -F '%FREQQUBIC=' '{print $2}')

while true; do
    response=$(curl -s http://qubic1.hk.apool.io:8001/api/qubic/mode | grep -o '"mode":[0-9]*' | awk -F: '{print $2}')

    if [ "$response" == "1" ]; then
        nvtool $FREQIDLE
    else
        nvtool $FREQQUBIC
    if
done
